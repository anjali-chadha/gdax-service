./apache-tomcat-7.0.84/bin/shutdown.sh
