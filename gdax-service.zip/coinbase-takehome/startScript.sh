unzip apache-tomcat-7.0.84.zip
sudo chmod -R 777 apache-tomcat-7.0.84
sudo chmod 777 shutdown.sh
rm -rf apache-tomcat-7.0.84/webapps/ROOT
mv webmvc.war ROOT.war
mv ROOT.war apache-tomcat-7.0.84/webapps
./apache-tomcat-7.0.84/bin/startup.sh

